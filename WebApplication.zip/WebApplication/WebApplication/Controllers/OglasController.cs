﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    public class OglasController : Controller
    {
        private ApplicationContext db = new ApplicationContext();

        // GET: Oglas
        public ActionResult Index()
        {
            var oglasi = db.Oglasi.Include(o => o.Kategorija).Include(o => o.User);
            return View(oglasi.ToList().Where<Oglas>(og => og.IsActive == true).OrderByDescending<Oglas, DateTime>(og => og.Date));
        }

        // GET: Oglas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Oglas oglas = db.Oglasi.Find(id);
            if (oglas == null)
            {
                return HttpNotFound();
            }
            return View(oglas);
        }

        // GET: Oglas/Create
        public ActionResult Create()
        {
            User user = (User)Session["user"];
            if (user != null && user.Pregledan == true)
            {
                ViewBag.KategorijaId = new SelectList(db.Kategorije, "Id", "Naziv");
                ViewBag.UserId = new SelectList(db.Users, "Id", "Username");
                return View();
            }
            else
            {
                return View("Obradjivanje");
            }
        }

        // POST: Oglas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Naslov,Opis,Cena,KategorijaId,UserId")] Oglas oglas)
        {
            User user = (User)(Session["user"]);
            oglas.UserId = user.Id;
            oglas.IsActive = true;
            oglas.Date = DateTime.Now;
            if (ModelState.IsValid)
            {
                db.Oglasi.Add(oglas);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.KategorijaId = new SelectList(db.Kategorije, "Id", "Naziv", oglas.KategorijaId);
            ViewBag.UserId = new SelectList(db.Users, "Id", "Username", oglas.UserId);
            return View(oglas);
        }

        // GET: Oglas/Edit/5
        public ActionResult Edit(int? id)
        {
            User user = (User)Session["user"];
            if (user != null && user.Pregledan == true)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Oglas oglas = db.Oglasi.Find(id);
                if (oglas == null)
                {
                    return HttpNotFound();
                }
                ViewBag.KategorijaId = new SelectList(db.Kategorije, "Id", "Naziv", oglas.KategorijaId);
                ViewBag.UserId = new SelectList(db.Users, "Id", "Username", oglas.UserId);
                return View(oglas);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Oglas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Naslov,Opis,Cena,KategorijaId,UserId")] Oglas oglas)
        {
            if (ModelState.IsValid)
            {
                db.Entry(oglas).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.KategorijaId = new SelectList(db.Kategorije, "Id", "Naziv", oglas.KategorijaId);
            ViewBag.UserId = new SelectList(db.Users, "Id", "Username", oglas.UserId);
            return View(oglas);
        }

        // GET: Oglas/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Oglas oglas = db.Oglasi.Find(id);
            if (oglas == null)
            {
                return HttpNotFound();
            }
            return View(oglas);
        }

        // POST: Oglas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Oglas oglas = db.Oglasi.Find(id);
            db.Oglasi.Remove(oglas);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}