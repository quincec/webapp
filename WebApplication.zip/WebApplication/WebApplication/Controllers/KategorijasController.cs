﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    public class KategorijasController : Controller
    {
        private ApplicationContext db = new ApplicationContext();

        // GET: Kategorijas
        public ActionResult Index()
        {
            User user = (User)Session["user"];
            if (user != null && user.Id == 1)
            {
                return View(db.Kategorije.ToList());
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // GET: Kategorijas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Kategorija kategorija = db.Kategorije.Find(id);
            if (kategorija == null)
            {
                return HttpNotFound();
            }
            return View(kategorija);
        }

        // GET: Kategorijas/Create
        public ActionResult Create()
        {
            User user = (User)Session["user"];
            if (user != null && user.Id == 1)
            {
                return View();
            } else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Kategorijas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Naziv")] Kategorija kategorija)
        { 
            if (ModelState.IsValid)
            {
                db.Kategorije.Add(kategorija);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(kategorija);
        }

        // GET: Kategorijas/Edit/5
        public ActionResult Edit(int? id)
        {
            User user = (User)Session["user"];
            if (user != null && user.Id == 1)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Kategorija kategorija = db.Kategorije.Find(id);
                if (kategorija == null)
                {
                    return HttpNotFound();
                }
                return View(kategorija);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Kategorijas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Naziv")] Kategorija kategorija)
        {
            if (ModelState.IsValid)
            {
                db.Entry(kategorija).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(kategorija);
        }

        // GET: Kategorijas/Delete/5
        public ActionResult Delete(int? id)
        {
            User user = (User)Session["user"];
            if (user != null && user.Id == 1)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Kategorija kategorija = db.Kategorije.Find(id);
                if (kategorija == null)
                {
                    return HttpNotFound();
                }
                return View(kategorija);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // POST: Kategorijas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Kategorija kategorija = db.Kategorije.Find(id);
            db.Kategorije.Remove(kategorija);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
