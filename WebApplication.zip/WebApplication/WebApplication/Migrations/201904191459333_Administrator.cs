namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Administrator : DbMigration
    {
        public override void Up()
        {
            Sql("INSERT INTO dbo.\"Users\"(\"Id\", \"Username\", \"Password\", \"FirstName\", \"LastName\", \"JMBG\", \"BrLK\", \"Email\", \"PhoneNumber\", \"IsValid\", \"Pregledan\") VALUES('1', 'admin', 'admin', 'Admin', 'Admin', '0123456789012', '01234567', 'admin@admin.com', '0123456789', 'true', 'true'); ");
        }
        
        public override void Down()
        {
        }
    }
}
