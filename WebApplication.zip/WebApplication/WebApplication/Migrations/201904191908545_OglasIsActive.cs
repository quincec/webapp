namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class OglasIsActive : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Oglas", "IsActive", c => c.Boolean(nullable: true));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Oglas", "IsActive");
        }
    }
}
