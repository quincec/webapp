namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UsersAdded : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "IsValid", c => c.Boolean(nullable: false));
            AddColumn("dbo.Users", "Pregledan", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Users", "Pregledan");
            DropColumn("dbo.Users", "IsValid");
        }
    }
}
