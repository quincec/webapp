namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PromenjenaCenaUString : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Oglas", "Cena", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Oglas", "Cena", c => c.Int(nullable: false));
        }
    }
}
