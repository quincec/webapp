namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migracija : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Kategorijas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Naziv = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Oglas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Naslov = c.String(nullable: false),
                        Opis = c.String(nullable: false),
                        Cena = c.Int(nullable: false),
                        KategorijaId = c.Int(nullable: false),
                        UserId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Kategorijas", t => t.KategorijaId, cascadeDelete: true)
                .ForeignKey("dbo.Users", t => t.UserId, cascadeDelete: true)
                .Index(t => t.KategorijaId)
                .Index(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Oglas", "UserId", "dbo.Users");
            DropForeignKey("dbo.Oglas", "KategorijaId", "dbo.Kategorijas");
            DropIndex("dbo.Oglas", new[] { "UserId" });
            DropIndex("dbo.Oglas", new[] { "KategorijaId" });
            DropTable("dbo.Oglas");
            DropTable("dbo.Kategorijas");
        }
    }
}
