namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class OglasDateAdded : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Oglas", "Date", c => c.DateTime(nullable: true));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Oglas", "Date");
        }
    }
}
