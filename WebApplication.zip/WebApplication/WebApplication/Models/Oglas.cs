﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication.Models
{
    public class Oglas
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string Naslov { get; set; }

        [Required]
        public string Opis { get; set; }
        
        [Ogranicavac]
        public string Cena { get; set; }
        
        public Kategorija Kategorija { get; set; }

        [Required]
        public int KategorijaId { get; set; }

        public User User { get; set; }

        [Required]
        public int UserId { get; set; }

        public bool IsActive { get; set; }

        public DateTime Date { get; set; }
    }
}