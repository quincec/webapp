﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication.Models
{
    public class User
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string Username{ get; set; }

        [Required]
        [MinLength(3)]
        public string Password { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        [MinLength(13)]
        [MaxLength(13)]
        public string JMBG { get; set; }

        [Required]
        [MinLength(8)]
        [MaxLength(8)]
        public string BrLK { get; set; }
        
        [EmailAddress]
        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        [Required]
        public bool IsValid { get; set; }

        [Required]
        public bool Pregledan { get; set; } //Znaci da mu je administrator odobrio postavljanje oglasa
    }
}