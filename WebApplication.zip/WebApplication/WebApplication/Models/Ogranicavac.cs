﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication.Models
{
    public class Ogranicavac : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext v)
        {
            Oglas oglas = (Oglas)(v.ObjectInstance);
            if (int.TryParse(oglas.Cena, out int n) || (oglas.Cena == "Kontakt" && oglas.User.PhoneNumber != null && oglas.User.PhoneNumber != "" && oglas.User.Email != null && oglas.User.Email != ""))
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Cena nije dobra");
            }
        }
    }
}